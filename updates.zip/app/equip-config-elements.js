// Page elements:
const toastContainer = document.querySelector('#toastContainer');

const equipmentItems = document.querySelectorAll('.inputElement');