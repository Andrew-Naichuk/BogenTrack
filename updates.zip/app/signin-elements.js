// Page elements:
const toastContainer = document.querySelector('#toastContainer');
const logInEmailField = document.querySelector('#loginEmail');
const logInPasswordField = document.querySelector('#loginPassword');
const logInButton = document.querySelector('#mainLoginBtn');
const logInGoogleButton = document.querySelector('#googleLoginBtn');