// Page elements:
const toastContainer = document.querySelector('#toastContainer');
const signOutButton = document.querySelector('#signOutBtn');
const userEmailIndicator = document.querySelector('#currentUserEmail');
const userSessionsIndicator = document.querySelector('#currentNumberOfSessions');
const downloadDataButton = document.querySelector('#downloadDataBtn');
const equipmentConfigsList = document.querySelector('#equipmentConfigsList');
const createNewEquipmentConfigButton = document.querySelector('#createNewEquipmentConfig');