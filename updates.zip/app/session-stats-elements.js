// Page elements:
const closeSessionStatsButton = document.querySelector('#closeSessionStatsBtn');