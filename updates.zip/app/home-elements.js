// Page elements:
const toastContainer = document.querySelector('#toastContainer');
const sessionsListScreen = document.querySelector('#sessionsListScreen');
const sessionsListContainer = document.querySelector('#sessionsListContainer');
const createSessionButton = document.querySelector('#createSessionBtn');