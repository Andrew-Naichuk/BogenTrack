// Page elements:
const toastContainer = document.querySelector('#toastContainer');
const RoundScreen = document.querySelector('#RoundScreen');
const roundNameIndicator = document.querySelector('#RoundName');
const backToSessionScreenButton = document.querySelector('#backToSessionScreenBtn');
const deleteRoundModalButton = document.querySelector('#deleteRoundModalBtn');
const confirmDeleteRoundModal = document.querySelector('#confirmDeleteRoundModal');
const deleteRoundButton = document.querySelector('#deleteRoundBtn');
const cancelDeleteRoundButton = document.querySelector('#cancelDeleteRoundBtn');
const arrowsListContainer = document.querySelector('#arrowsListContainer');