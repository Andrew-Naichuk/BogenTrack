// Page elements:
const toastContainer = document.querySelector('#toastContainer');
const reportsList = document.querySelector('#reportsList');
const reportTextField = document.querySelector('#reportText');
const submitReportButton = document.querySelector('#submitReportBtn');
const cancelReportButton = document.querySelector('#cancelReportBtn');