// Page elements:
const toastContainer = document.querySelector('#toastContainer');
const signUpForm = document.querySelector('#signupForm');
const signUpemailField = document.querySelector('#signupEmail');
const signUppasswordField = document.querySelector('#signupPassword');
const signUpButton = document.querySelector('#mainSignupBtn');
const toLogInForm = document.querySelector('#toLoginBtn');